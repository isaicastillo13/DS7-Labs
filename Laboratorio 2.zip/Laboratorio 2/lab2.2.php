<?php
require ("noexiste.php");
echo ("hola. El script no siguio!");
?>