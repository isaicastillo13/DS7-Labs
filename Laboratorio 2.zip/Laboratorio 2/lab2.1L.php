<?php include ("lab2.1_H.php"); ?>
<p>
    Hola, aqui esta el contenido que se mando.
</p>
<?php include("lab2.1F.php");?>