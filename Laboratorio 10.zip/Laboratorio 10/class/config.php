<?php
//Definimos constantes para conectar a la base de datos.
//Nombre del servidor MySQL (probablemente localhost)
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','laboratorios_db');

?>